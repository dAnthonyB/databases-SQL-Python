--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.user_sub_bug DROP CONSTRAINT user_sub_bug_user_id_fkey;
ALTER TABLE ONLY public.user_sub_bug DROP CONSTRAINT user_sub_bug_bug_id_fkey;
ALTER TABLE ONLY public.user_assigned_bug DROP CONSTRAINT user_assigned_bug_user_id_fkey;
ALTER TABLE ONLY public.user_assigned_bug DROP CONSTRAINT user_assigned_bug_bug_id_fkey;
ALTER TABLE ONLY public.tag DROP CONSTRAINT tag_bug_id_fkey;
ALTER TABLE ONLY public.mention DROP CONSTRAINT mention_user_id_fkey;
ALTER TABLE ONLY public.mention DROP CONSTRAINT mention_comment_id_fkey;
ALTER TABLE ONLY public.comment DROP CONSTRAINT comment_bug_id_fkey;
ALTER TABLE ONLY public.comment DROP CONSTRAINT comment_author_id_fkey;
ALTER TABLE ONLY public.bug_milestone DROP CONSTRAINT bug_milestone_milestone_id_fkey;
ALTER TABLE ONLY public.bug_milestone DROP CONSTRAINT bug_milestone_bug_id_fkey;
ALTER TABLE ONLY public.bug DROP CONSTRAINT bug_creator_id_fkey;
SET search_path = project, pg_catalog;

ALTER TABLE ONLY project.user_sub_bug DROP CONSTRAINT user_sub_bug_user_id_fkey;
ALTER TABLE ONLY project.user_sub_bug DROP CONSTRAINT user_sub_bug_bug_id_fkey;
ALTER TABLE ONLY project.user_assigned_bug DROP CONSTRAINT user_assigned_bug_user_id_fkey;
ALTER TABLE ONLY project.user_assigned_bug DROP CONSTRAINT user_assigned_bug_bug_id_fkey;
ALTER TABLE ONLY project.tag DROP CONSTRAINT tag_bug_id_fkey;
ALTER TABLE ONLY project.mention DROP CONSTRAINT mention_user_id_fkey;
ALTER TABLE ONLY project.mention DROP CONSTRAINT mention_comment_id_fkey;
ALTER TABLE ONLY project.comment DROP CONSTRAINT comment_bug_id_fkey;
ALTER TABLE ONLY project.comment DROP CONSTRAINT comment_author_id_fkey;
ALTER TABLE ONLY project.bug_milestone DROP CONSTRAINT bug_milestone_milestone_id_fkey;
ALTER TABLE ONLY project.bug_milestone DROP CONSTRAINT bug_milestone_bug_id_fkey;
ALTER TABLE ONLY project.bug DROP CONSTRAINT bug_creator_id_fkey;
SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."user" DROP CONSTRAINT user_username_key;
ALTER TABLE ONLY public.user_sub_bug DROP CONSTRAINT user_sub_bug_pkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_email_key;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_display_name_key;
ALTER TABLE ONLY public.user_assigned_bug DROP CONSTRAINT user_assigned_bug_pkey;
ALTER TABLE ONLY public.tag DROP CONSTRAINT tag_pkey;
ALTER TABLE ONLY public.milestone DROP CONSTRAINT milestone_pkey;
ALTER TABLE ONLY public.milestone DROP CONSTRAINT milestone_milestone_name_key;
ALTER TABLE ONLY public.mention DROP CONSTRAINT mention_pkey;
ALTER TABLE ONLY public.comment DROP CONSTRAINT comment_pkey;
ALTER TABLE ONLY public.bug DROP CONSTRAINT bug_pkey;
ALTER TABLE ONLY public.bug_milestone DROP CONSTRAINT bug_milestone_pkey;
ALTER TABLE ONLY public.bug DROP CONSTRAINT bug_bug_title_key;
SET search_path = project, pg_catalog;

ALTER TABLE ONLY project."user" DROP CONSTRAINT user_username_key;
ALTER TABLE ONLY project.user_sub_bug DROP CONSTRAINT user_sub_bug_pkey;
ALTER TABLE ONLY project."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY project."user" DROP CONSTRAINT user_email_key;
ALTER TABLE ONLY project."user" DROP CONSTRAINT user_display_name_key;
ALTER TABLE ONLY project.user_assigned_bug DROP CONSTRAINT user_assigned_bug_pkey;
ALTER TABLE ONLY project.tag DROP CONSTRAINT tag_pkey;
ALTER TABLE ONLY project.milestone DROP CONSTRAINT milestone_pkey;
ALTER TABLE ONLY project.milestone DROP CONSTRAINT milestone_milestone_name_key;
ALTER TABLE ONLY project.mention DROP CONSTRAINT mention_pkey;
ALTER TABLE ONLY project.comment DROP CONSTRAINT comment_pkey;
ALTER TABLE ONLY project.bug DROP CONSTRAINT bug_pkey;
ALTER TABLE ONLY project.bug_milestone DROP CONSTRAINT bug_milestone_pkey;
ALTER TABLE ONLY project.bug DROP CONSTRAINT bug_bug_title_key;
SET search_path = public, pg_catalog;

SET search_path = project, pg_catalog;

SET search_path = public, pg_catalog;

ALTER TABLE public."user" ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE public.tag ALTER COLUMN tag_id DROP DEFAULT;
ALTER TABLE public.milestone ALTER COLUMN milestone_id DROP DEFAULT;
ALTER TABLE public.comment ALTER COLUMN comment_id DROP DEFAULT;
ALTER TABLE public.bug ALTER COLUMN bug_id DROP DEFAULT;
SET search_path = project, pg_catalog;

ALTER TABLE project."user" ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE project.tag ALTER COLUMN tag_id DROP DEFAULT;
ALTER TABLE project.milestone ALTER COLUMN milestone_id DROP DEFAULT;
ALTER TABLE project.comment ALTER COLUMN comment_id DROP DEFAULT;
ALTER TABLE project.bug ALTER COLUMN bug_id DROP DEFAULT;
SET search_path = public, pg_catalog;

DROP SEQUENCE public.user_user_id_seq;
DROP TABLE public.user_sub_bug;
DROP TABLE public.user_assigned_bug;
DROP TABLE public."user";
DROP SEQUENCE public.tag_tag_id_seq;
DROP TABLE public.tag;
DROP SEQUENCE public.milestone_milestone_id_seq;
DROP TABLE public.milestone;
DROP TABLE public.mention;
DROP SEQUENCE public.comment_comment_id_seq;
DROP TABLE public.comment;
DROP TABLE public.bug_milestone;
DROP SEQUENCE public.bug_bug_id_seq;
DROP TABLE public.bug;
SET search_path = project, pg_catalog;

DROP SEQUENCE project.user_user_id_seq;
DROP TABLE project.user_sub_bug;
DROP TABLE project.user_assigned_bug;
DROP TABLE project."user";
DROP SEQUENCE project.tag_tag_id_seq;
DROP TABLE project.tag;
DROP SEQUENCE project.milestone_milestone_id_seq;
DROP TABLE project.milestone;
DROP TABLE project.mention;
DROP SEQUENCE project.comment_comment_id_seq;
DROP TABLE project.comment;
DROP TABLE project.bug_milestone;
DROP SEQUENCE project.bug_bug_id_seq;
DROP TABLE project.bug;
SET search_path = public, pg_catalog;

DROP TYPE public.user_role;
DROP TYPE public.stat;
SET search_path = project, pg_catalog;

DROP TYPE project.user_role;
DROP TYPE project.stat;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA project;
--
-- Name: project; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA project;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = project, pg_catalog;

--
-- Name: stat; Type: TYPE; Schema: project; Owner: -
--

CREATE TYPE stat AS ENUM (
    'closed',
    'open',
    'rejected'
);


--
-- Name: user_role; Type: TYPE; Schema: project; Owner: -
--

CREATE TYPE user_role AS ENUM (
    'user',
    'developer'
);


SET search_path = public, pg_catalog;

--
-- Name: stat; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE stat AS ENUM (
    'closed',
    'open',
    'rejected'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE user_role AS ENUM (
    'user',
    'developer'
);


SET search_path = project, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: bug; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE bug (
    bug_id integer NOT NULL,
    bug_title character varying NOT NULL,
    creator_id integer NOT NULL,
    creation_date timestamp without time zone DEFAULT now() NOT NULL,
    bug_details character varying DEFAULT ''::character varying,
    status stat DEFAULT 'open'::stat NOT NULL,
    close_date timestamp without time zone
);


--
-- Name: bug_bug_id_seq; Type: SEQUENCE; Schema: project; Owner: -
--

CREATE SEQUENCE bug_bug_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bug_bug_id_seq; Type: SEQUENCE OWNED BY; Schema: project; Owner: -
--

ALTER SEQUENCE bug_bug_id_seq OWNED BY bug.bug_id;


--
-- Name: bug_milestone; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE bug_milestone (
    milestone_id integer NOT NULL,
    bug_id integer NOT NULL
);


--
-- Name: comment; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE comment (
    comment_id integer NOT NULL,
    author_id integer NOT NULL,
    bug_id integer NOT NULL,
    comment_text character varying NOT NULL,
    comment_date timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: comment_comment_id_seq; Type: SEQUENCE; Schema: project; Owner: -
--

CREATE SEQUENCE comment_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: project; Owner: -
--

ALTER SEQUENCE comment_comment_id_seq OWNED BY comment.comment_id;


--
-- Name: mention; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE mention (
    user_id integer NOT NULL,
    comment_id integer NOT NULL
);


--
-- Name: milestone; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE milestone (
    milestone_id integer NOT NULL,
    milestone_name character varying NOT NULL,
    milestone_description character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: milestone_milestone_id_seq; Type: SEQUENCE; Schema: project; Owner: -
--

CREATE SEQUENCE milestone_milestone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: milestone_milestone_id_seq; Type: SEQUENCE OWNED BY; Schema: project; Owner: -
--

ALTER SEQUENCE milestone_milestone_id_seq OWNED BY milestone.milestone_id;


--
-- Name: tag; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE tag (
    tag_id integer NOT NULL,
    bug_id integer NOT NULL,
    tag_name character varying NOT NULL
);


--
-- Name: tag_tag_id_seq; Type: SEQUENCE; Schema: project; Owner: -
--

CREATE SEQUENCE tag_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tag_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: project; Owner: -
--

ALTER SEQUENCE tag_tag_id_seq OWNED BY tag.tag_id;


--
-- Name: user; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE "user" (
    user_id integer NOT NULL,
    username character varying NOT NULL,
    display_name character varying NOT NULL,
    pw_hash character varying NOT NULL,
    email character varying NOT NULL,
    role user_role DEFAULT 'user'::user_role NOT NULL
);


--
-- Name: user_assigned_bug; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE user_assigned_bug (
    user_id integer NOT NULL,
    bug_id integer NOT NULL,
    assign_date timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_sub_bug; Type: TABLE; Schema: project; Owner: -; Tablespace: 
--

CREATE TABLE user_sub_bug (
    user_id integer NOT NULL,
    bug_id integer NOT NULL
);


--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: project; Owner: -
--

CREATE SEQUENCE user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: project; Owner: -
--

ALTER SEQUENCE user_user_id_seq OWNED BY "user".user_id;


SET search_path = public, pg_catalog;

--
-- Name: bug; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE bug (
    bug_id integer NOT NULL,
    bug_title character varying NOT NULL,
    creator_id integer NOT NULL,
    creation_date timestamp without time zone DEFAULT now() NOT NULL,
    bug_details character varying DEFAULT ''::character varying,
    status stat DEFAULT 'open'::stat NOT NULL,
    close_date timestamp without time zone
);


--
-- Name: bug_bug_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE bug_bug_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bug_bug_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE bug_bug_id_seq OWNED BY bug.bug_id;


--
-- Name: bug_milestone; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE bug_milestone (
    milestone_id integer NOT NULL,
    bug_id integer NOT NULL
);


--
-- Name: comment; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE comment (
    comment_id integer NOT NULL,
    author_id integer NOT NULL,
    bug_id integer NOT NULL,
    comment_text character varying NOT NULL,
    comment_date timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: comment_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE comment_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE comment_comment_id_seq OWNED BY comment.comment_id;


--
-- Name: mention; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE mention (
    user_id integer NOT NULL,
    comment_id integer NOT NULL
);


--
-- Name: milestone; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE milestone (
    milestone_id integer NOT NULL,
    milestone_name character varying NOT NULL,
    milestone_description character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: milestone_milestone_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE milestone_milestone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: milestone_milestone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE milestone_milestone_id_seq OWNED BY milestone.milestone_id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tag (
    tag_id integer NOT NULL,
    bug_id integer NOT NULL,
    tag_name character varying NOT NULL
);


--
-- Name: tag_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tag_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tag_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tag_tag_id_seq OWNED BY tag.tag_id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE "user" (
    user_id integer NOT NULL,
    username character varying NOT NULL,
    display_name character varying NOT NULL,
    pw_hash character varying NOT NULL,
    email character varying NOT NULL,
    role user_role DEFAULT 'user'::user_role NOT NULL
);


--
-- Name: user_assigned_bug; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_assigned_bug (
    user_id integer NOT NULL,
    bug_id integer NOT NULL,
    assign_date timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_sub_bug; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_sub_bug (
    user_id integer NOT NULL,
    bug_id integer NOT NULL
);


--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_user_id_seq OWNED BY "user".user_id;


SET search_path = project, pg_catalog;

--
-- Name: bug_id; Type: DEFAULT; Schema: project; Owner: -
--

ALTER TABLE ONLY bug ALTER COLUMN bug_id SET DEFAULT nextval('bug_bug_id_seq'::regclass);


--
-- Name: comment_id; Type: DEFAULT; Schema: project; Owner: -
--

ALTER TABLE ONLY comment ALTER COLUMN comment_id SET DEFAULT nextval('comment_comment_id_seq'::regclass);


--
-- Name: milestone_id; Type: DEFAULT; Schema: project; Owner: -
--

ALTER TABLE ONLY milestone ALTER COLUMN milestone_id SET DEFAULT nextval('milestone_milestone_id_seq'::regclass);


--
-- Name: tag_id; Type: DEFAULT; Schema: project; Owner: -
--

ALTER TABLE ONLY tag ALTER COLUMN tag_id SET DEFAULT nextval('tag_tag_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: project; Owner: -
--

ALTER TABLE ONLY "user" ALTER COLUMN user_id SET DEFAULT nextval('user_user_id_seq'::regclass);


SET search_path = public, pg_catalog;

--
-- Name: bug_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY bug ALTER COLUMN bug_id SET DEFAULT nextval('bug_bug_id_seq'::regclass);


--
-- Name: comment_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY comment ALTER COLUMN comment_id SET DEFAULT nextval('comment_comment_id_seq'::regclass);


--
-- Name: milestone_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY milestone ALTER COLUMN milestone_id SET DEFAULT nextval('milestone_milestone_id_seq'::regclass);


--
-- Name: tag_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY tag ALTER COLUMN tag_id SET DEFAULT nextval('tag_tag_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "user" ALTER COLUMN user_id SET DEFAULT nextval('user_user_id_seq'::regclass);


SET search_path = project, pg_catalog;

--
-- Data for Name: bug; Type: TABLE DATA; Schema: project; Owner: -
--

COPY bug (bug_id, bug_title, creator_id, creation_date, bug_details, status, close_date) FROM stdin;
3	bugTitle3	2	2015-11-22 15:22:03.512118	bug_details3	open	\N
4	bugTitle4	2	2015-11-22 15:22:03.512118	bug_details4	open	\N
1	bugTitle1	2	2015-11-22 15:22:03.512118	bug_details1	closed	2015-11-22 19:29:40.761279
2	bugTitle2	2	2015-11-22 15:22:03.512118	bug_details2	closed	2015-11-22 19:29:40.761279
\.


--
-- Name: bug_bug_id_seq; Type: SEQUENCE SET; Schema: project; Owner: -
--

SELECT pg_catalog.setval('bug_bug_id_seq', 4, true);


--
-- Data for Name: bug_milestone; Type: TABLE DATA; Schema: project; Owner: -
--

COPY bug_milestone (milestone_id, bug_id) FROM stdin;
1	1
1	2
1	3
1	4
2	1
2	3
2	4
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: project; Owner: -
--

COPY comment (comment_id, author_id, bug_id, comment_text, comment_date) FROM stdin;
1	1	1	comment_text0: @username1	2015-11-22 15:22:03.857897
\.


--
-- Name: comment_comment_id_seq; Type: SEQUENCE SET; Schema: project; Owner: -
--

SELECT pg_catalog.setval('comment_comment_id_seq', 1, true);


--
-- Data for Name: mention; Type: TABLE DATA; Schema: project; Owner: -
--

COPY mention (user_id, comment_id) FROM stdin;
2	1
\.


--
-- Data for Name: milestone; Type: TABLE DATA; Schema: project; Owner: -
--

COPY milestone (milestone_id, milestone_name, milestone_description) FROM stdin;
1	milestone_name0	milestone_desc0
2	milestone_name1	milestone_desc1
\.


--
-- Name: milestone_milestone_id_seq; Type: SEQUENCE SET; Schema: project; Owner: -
--

SELECT pg_catalog.setval('milestone_milestone_id_seq', 2, true);


--
-- Data for Name: tag; Type: TABLE DATA; Schema: project; Owner: -
--

COPY tag (tag_id, bug_id, tag_name) FROM stdin;
1	1	tag_name0
\.


--
-- Name: tag_tag_id_seq; Type: SEQUENCE SET; Schema: project; Owner: -
--

SELECT pg_catalog.setval('tag_tag_id_seq', 1, true);


--
-- Data for Name: user; Type: TABLE DATA; Schema: project; Owner: -
--

COPY "user" (user_id, username, display_name, pw_hash, email, role) FROM stdin;
1	username1	displayname1	password1	1@txstate.edu	user
2	username2	displayname2	password2	2@txstate.edu	developer
\.


--
-- Data for Name: user_assigned_bug; Type: TABLE DATA; Schema: project; Owner: -
--

COPY user_assigned_bug (user_id, bug_id, assign_date) FROM stdin;
2	1	2015-11-22 15:22:03.712879
2	2	2015-11-22 15:22:03.712879
\.


--
-- Data for Name: user_sub_bug; Type: TABLE DATA; Schema: project; Owner: -
--

COPY user_sub_bug (user_id, bug_id) FROM stdin;
1	1
2	1
2	2
\.


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: project; Owner: -
--

SELECT pg_catalog.setval('user_user_id_seq', 2, true);


SET search_path = public, pg_catalog;

--
-- Data for Name: bug; Type: TABLE DATA; Schema: public; Owner: -
--

COPY bug (bug_id, bug_title, creator_id, creation_date, bug_details, status, close_date) FROM stdin;
3	bugTitle3	2	2015-11-30 19:28:32.707233	bug_details3	open	\N
4	bugTitle4	2	2015-11-30 19:28:32.707233	bug_details4	open	\N
1	bugTitle1	2	2015-11-30 19:28:32.707233	bug_details1	closed	2015-11-30 19:28:32.745343
2	bugTitle2	2	2015-11-30 19:28:32.707233	bug_details2	closed	2015-11-30 19:28:32.745343
\.


--
-- Name: bug_bug_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('bug_bug_id_seq', 4, true);


--
-- Data for Name: bug_milestone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY bug_milestone (milestone_id, bug_id) FROM stdin;
1	1
1	2
1	3
1	4
2	1
2	3
2	4
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY comment (comment_id, author_id, bug_id, comment_text, comment_date) FROM stdin;
1	1	1	comment_text0: @username1	2015-11-30 19:28:32.858476
\.


--
-- Name: comment_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('comment_comment_id_seq', 1, true);


--
-- Data for Name: mention; Type: TABLE DATA; Schema: public; Owner: -
--

COPY mention (user_id, comment_id) FROM stdin;
2	1
\.


--
-- Data for Name: milestone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY milestone (milestone_id, milestone_name, milestone_description) FROM stdin;
1	milestone_name0	milestone_desc0
2	milestone_name1	milestone_desc1
\.


--
-- Name: milestone_milestone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('milestone_milestone_id_seq', 2, true);


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tag (tag_id, bug_id, tag_name) FROM stdin;
1	1	tag_name0
\.


--
-- Name: tag_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tag_tag_id_seq', 1, true);


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "user" (user_id, username, display_name, pw_hash, email, role) FROM stdin;
1	username1	displayname1	password1	1@txstate.edu	user
2	username2	displayname2	password2	2@txstate.edu	developer
\.


--
-- Data for Name: user_assigned_bug; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_assigned_bug (user_id, bug_id, assign_date) FROM stdin;
2	1	2015-11-30 19:28:32.808882
2	2	2015-11-30 19:28:32.808882
\.


--
-- Data for Name: user_sub_bug; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_sub_bug (user_id, bug_id) FROM stdin;
1	1
2	1
2	2
\.


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_user_id_seq', 2, true);


SET search_path = project, pg_catalog;

--
-- Name: bug_bug_title_key; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bug
    ADD CONSTRAINT bug_bug_title_key UNIQUE (bug_title);


--
-- Name: bug_milestone_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bug_milestone
    ADD CONSTRAINT bug_milestone_pkey PRIMARY KEY (milestone_id, bug_id);


--
-- Name: bug_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bug
    ADD CONSTRAINT bug_pkey PRIMARY KEY (bug_id);


--
-- Name: comment_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (comment_id);


--
-- Name: mention_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY mention
    ADD CONSTRAINT mention_pkey PRIMARY KEY (user_id, comment_id);


--
-- Name: milestone_milestone_name_key; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY milestone
    ADD CONSTRAINT milestone_milestone_name_key UNIQUE (milestone_name);


--
-- Name: milestone_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (milestone_id);


--
-- Name: tag_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (tag_id);


--
-- Name: user_assigned_bug_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_assigned_bug
    ADD CONSTRAINT user_assigned_bug_pkey PRIMARY KEY (user_id, bug_id);


--
-- Name: user_display_name_key; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_display_name_key UNIQUE (display_name);


--
-- Name: user_email_key; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: user_sub_bug_pkey; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_sub_bug
    ADD CONSTRAINT user_sub_bug_pkey PRIMARY KEY (user_id, bug_id);


--
-- Name: user_username_key; Type: CONSTRAINT; Schema: project; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


SET search_path = public, pg_catalog;

--
-- Name: bug_bug_title_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bug
    ADD CONSTRAINT bug_bug_title_key UNIQUE (bug_title);


--
-- Name: bug_milestone_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bug_milestone
    ADD CONSTRAINT bug_milestone_pkey PRIMARY KEY (milestone_id, bug_id);


--
-- Name: bug_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bug
    ADD CONSTRAINT bug_pkey PRIMARY KEY (bug_id);


--
-- Name: comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (comment_id);


--
-- Name: mention_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY mention
    ADD CONSTRAINT mention_pkey PRIMARY KEY (user_id, comment_id);


--
-- Name: milestone_milestone_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY milestone
    ADD CONSTRAINT milestone_milestone_name_key UNIQUE (milestone_name);


--
-- Name: milestone_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (milestone_id);


--
-- Name: tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (tag_id);


--
-- Name: user_assigned_bug_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_assigned_bug
    ADD CONSTRAINT user_assigned_bug_pkey PRIMARY KEY (user_id, bug_id);


--
-- Name: user_display_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_display_name_key UNIQUE (display_name);


--
-- Name: user_email_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: user_sub_bug_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_sub_bug
    ADD CONSTRAINT user_sub_bug_pkey PRIMARY KEY (user_id, bug_id);


--
-- Name: user_username_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


SET search_path = project, pg_catalog;

--
-- Name: bug_creator_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY bug
    ADD CONSTRAINT bug_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES "user"(user_id);


--
-- Name: bug_milestone_bug_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY bug_milestone
    ADD CONSTRAINT bug_milestone_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: bug_milestone_milestone_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY bug_milestone
    ADD CONSTRAINT bug_milestone_milestone_id_fkey FOREIGN KEY (milestone_id) REFERENCES milestone(milestone_id);


--
-- Name: comment_author_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_author_id_fkey FOREIGN KEY (author_id) REFERENCES "user"(user_id);


--
-- Name: comment_bug_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: mention_comment_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY mention
    ADD CONSTRAINT mention_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES comment(comment_id);


--
-- Name: mention_user_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY mention
    ADD CONSTRAINT mention_user_id_fkey FOREIGN KEY (user_id) REFERENCES "user"(user_id);


--
-- Name: tag_bug_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: user_assigned_bug_bug_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY user_assigned_bug
    ADD CONSTRAINT user_assigned_bug_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: user_assigned_bug_user_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY user_assigned_bug
    ADD CONSTRAINT user_assigned_bug_user_id_fkey FOREIGN KEY (user_id) REFERENCES "user"(user_id);


--
-- Name: user_sub_bug_bug_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY user_sub_bug
    ADD CONSTRAINT user_sub_bug_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: user_sub_bug_user_id_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY user_sub_bug
    ADD CONSTRAINT user_sub_bug_user_id_fkey FOREIGN KEY (user_id) REFERENCES "user"(user_id);


SET search_path = public, pg_catalog;

--
-- Name: bug_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bug
    ADD CONSTRAINT bug_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES "user"(user_id);


--
-- Name: bug_milestone_bug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bug_milestone
    ADD CONSTRAINT bug_milestone_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: bug_milestone_milestone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bug_milestone
    ADD CONSTRAINT bug_milestone_milestone_id_fkey FOREIGN KEY (milestone_id) REFERENCES milestone(milestone_id);


--
-- Name: comment_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_author_id_fkey FOREIGN KEY (author_id) REFERENCES "user"(user_id);


--
-- Name: comment_bug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY comment
    ADD CONSTRAINT comment_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: mention_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY mention
    ADD CONSTRAINT mention_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES comment(comment_id);


--
-- Name: mention_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY mention
    ADD CONSTRAINT mention_user_id_fkey FOREIGN KEY (user_id) REFERENCES "user"(user_id);


--
-- Name: tag_bug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: user_assigned_bug_bug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_assigned_bug
    ADD CONSTRAINT user_assigned_bug_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: user_assigned_bug_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_assigned_bug
    ADD CONSTRAINT user_assigned_bug_user_id_fkey FOREIGN KEY (user_id) REFERENCES "user"(user_id);


--
-- Name: user_sub_bug_bug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_sub_bug
    ADD CONSTRAINT user_sub_bug_bug_id_fkey FOREIGN KEY (bug_id) REFERENCES bug(bug_id);


--
-- Name: user_sub_bug_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_sub_bug
    ADD CONSTRAINT user_sub_bug_user_id_fkey FOREIGN KEY (user_id) REFERENCES "user"(user_id);


--
-- PostgreSQL database dump complete
--

