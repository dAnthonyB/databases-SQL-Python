# This settings file configures your application

# Provide debugging information
DEBUG = True

SERVER_NAME = 'localhost:5143'

# Where is the database file?
PG_ARGS = {'database': 'dab143', 'password': 'Shrimpfist123!', 'host': 'postgresql.cs.txstate.edu'}
